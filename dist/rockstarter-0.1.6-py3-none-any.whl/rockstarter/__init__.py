# rockstart/__init__.py
from .commands import main
